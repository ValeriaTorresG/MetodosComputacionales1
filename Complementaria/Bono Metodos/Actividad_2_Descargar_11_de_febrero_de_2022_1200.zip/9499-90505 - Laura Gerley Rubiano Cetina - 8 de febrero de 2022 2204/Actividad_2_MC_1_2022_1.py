{
 "cells": [
  {
   "cell_type": "markdown",
   "id": "7a239049",
   "metadata": {},
   "source": [
    " # Números Complejos"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "03912364",
   "metadata": {},
   "source": [
    "## Operaciones Basicas"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "id": "8588d91d",
   "metadata": {},
   "outputs": [],
   "source": [
    "class complejos:\n",
    "        def __init__(self,Real,Ima): # Se definen los atributos \n",
    "            self.Real=Real # objeto.atributo = valor\n",
    "            self.Ima=Ima  # objeto.atributo = valor\n",
    "            \n",
    "        def suma (self,otro): # Funcion \n",
    "            a= self.Real+otro.Real # Variable de suma de realaes\n",
    "            b= self.Ima+otro.Ima   # Variable de suma de Imaginarios\n",
    "            return a,b\n",
    "        def resta (self,otro):\n",
    "            a= self.Real-otro.Real # Resta de Reales \n",
    "            b= self.Ima-otro.Ima   # Resta de Imaginarios\n",
    "            return a,b\n",
    "        def multi (self,otro):\n",
    "            a= (self.Real*otro.Real)-(otro.Real*otro.Ima) # Multiplicacion por ley distributiva\n",
    "            b= (self.Real*otro.Ima)+(self.Ima*otro.Real)\n",
    "            return a,b\n",
    "        def divi(self,otro):\n",
    "            a= ((self.Real*otro.Real)+(otro.Real*otro.Ima))/((otro.Real)**2+(otro.Ima)**2) # Division, mulriplicando por el conjugado tanto en el numerador como denominador.\n",
    "            b= ((self.Ima*otro.Real)-(self.Real*otro.Ima))/((otro.Real)**2+(otro.Ima)**2)\n",
    "            return a,b\n",
    "        def norma(self): # Raiz del numero real y complejo elevado al cuadrado\n",
    "            a=((self.Real**2+self.Ima**2))**(1/2)\n",
    "            return a"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "6fffd754",
   "metadata": {},
   "source": [
    "## Ejemplo 1 - SUMA"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 25,
   "id": "232f67f7",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(3, 5)"
      ]
     },
     "execution_count": 25,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(1,2)\n",
    "z2=complejos(2,3)\n",
    "z1.suma(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "bf7fc3e5",
   "metadata": {},
   "source": [
    "## Ejemplo 2 - SUMA"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 26,
   "id": "4cde096f",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(5, 11)"
      ]
     },
     "execution_count": 26,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(7,8)\n",
    "z2=complejos(-2,3)\n",
    "z1.suma(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "0c9583bc",
   "metadata": {},
   "source": [
    "## Ejemplo 1 - RESTA"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 27,
   "id": "19943cb9",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(-1, -1)"
      ]
     },
     "execution_count": 27,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(1,2)\n",
    "z2=complejos(2,3)\n",
    "z1.resta(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "94612825",
   "metadata": {},
   "source": [
    "## Ejerplo 2 - RESTA"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 28,
   "id": "4ab74d31",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(-29, -2)"
      ]
     },
     "execution_count": 28,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(-22,2)\n",
    "z2=complejos(7,4)\n",
    "z1.resta(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "5d7aceb0",
   "metadata": {},
   "source": [
    "## Ejemplo 1 - Multiplicación"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "325364b1",
   "metadata": {},
   "source": [
    "z1=complejos(1,2)\n",
    "z2=complejos(2,3)\n",
    "z1.multi(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "7d44b0ad",
   "metadata": {},
   "source": [
    "## Ejemplo 2 - Multiplicación"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "id": "205ddb08",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(70, 7)"
      ]
     },
     "execution_count": 30,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(7,4)\n",
    "z2=complejos(7,-3)\n",
    "z1.multi(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "81bd70fb",
   "metadata": {},
   "source": [
    "## Ejemplo 1 - División"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 31,
   "id": "fafd4fa3",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(0.6153846153846154, 0.07692307692307693)"
      ]
     },
     "execution_count": 31,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(1,2)\n",
    "z2=complejos(2,3)\n",
    "z1.divi(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "6f72640a",
   "metadata": {},
   "source": [
    "## Ejemplo 2 - División"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 32,
   "id": "57a822d9",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "(0.5603448275862069, 0.3017241379310345)"
      ]
     },
     "execution_count": 32,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(5,9)\n",
    "z2=complejos(20,8)\n",
    "z1.divi(z2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "25e999a8",
   "metadata": {},
   "source": [
    "## Ejemplo 1 - Norma "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 33,
   "id": "82984427",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "2.23606797749979"
      ]
     },
     "execution_count": 33,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(1,2)\n",
    "z1.norma()"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "a4b23164",
   "metadata": {},
   "source": [
    "## Ejemplo 2 - Norma"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 34,
   "id": "831c159b",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "91.67878707749138"
      ]
     },
     "execution_count": 34,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "z1=complejos(89,22)\n",
    "z1.norma()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d98c6f2f",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
